import"./chunk-b3cdbad1.js";document.querySelector("#app").innerHTML=`
  <main>
    <h3>Popup Page!</h3>
    <h6>v 0.0.0</h6>
  </main>
`;
