console.info("chrome-ext template-vanilla-ts content script");
